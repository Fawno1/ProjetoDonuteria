package br.com.fundatec.Donuteria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DonuteriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DonuteriaApplication.class, args);
	}

}
